// class marque.model.ts
export class Marque {
  id?: number;
  nom: string;

  constructor(){

    this.nom ='';

  }
}

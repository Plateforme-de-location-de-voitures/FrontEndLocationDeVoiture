import { Component } from '@angular/core';
import { VoitureService } from 'src/app/services/voiture.service';

@Component({
  selector: 'app-details-voiture',
  templateUrl: './details-voiture.component.html',
  styleUrls: ['./details-voiture.component.css']
})
export class DetailsVoitureComponent {

}

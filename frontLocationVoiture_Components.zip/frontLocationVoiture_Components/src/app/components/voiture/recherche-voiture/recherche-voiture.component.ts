import { Component } from '@angular/core';

@Component({
  selector: 'app-recherche-voiture',
  templateUrl: './recherche-voiture.component.html',
  styleUrls: ['./recherche-voiture.component.css']
})
export class RechercheVoitureComponent {

}
